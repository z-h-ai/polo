父任务：POL-111

# 第一站：共享身份、登录与端边界访谈

## Intent

先把“谁、从哪里、以什么身份、进入哪个端、看到什么、离开后怎样回来”讲清楚，使后续四端访谈消费同一套边界。不要直接把四端等同于四套账号，也不要默认需要统一登录。

## 已有规则与需验证的落差

- POL-68 的企业/创作者流程规定：仅从 Polo 客户端账号菜单进入浏览器；企业 Owner/Manager 可进入企业管理端；创作者是普通账号的资格，资格暂停/撤销保留责任处理只读入口；两个管理端无互跳且退出后重新登录。
- 平台运营使用独立工作人员账号，不从普通客户端进入；业务身份与平台身份分离。POL-88 已将这些要求写入入口/session 拆分范围。
- Admin 集成首页却展示三入口并说明独立会话。需要核实它是内部导航页、公开落地页还是临时调试页；首页展示、受控入口、合法深链和禁止直接进入分别适用于谁。

## Agent 先做的事实工作

对照文档、POL-77/POL-88/POL-90、相关认证页面/会话检查及客户端账号菜单；制作“身份 × 准入资格 × 入口 × 会话 × 登录后落点 × 拒绝/恢复 × 数据/付款上下文”表。区分业务账号、企业内角色、创作者资格、工作人员账号、ProductSpace；任何合并/简化均先标成建议。

核实首个工作人员账号如何开通、后续员工授权/撤权、最后一个有效管理员保护；Polo 账号注册/找回、创作者申请、首次创建企业与未具备资格时去哪里。现有证据无法回答的标为缺口，不擅自确定认证方式。

## 在本卡启动访谈的例子

1. 小李是企业 Owner，也是创作者：从桌面端进入企业管理后想发布作品，应看到什么、是否要退出、再次登录是否丢失原页面？
2. 普通成员误点 Platform admin login，或打开企业管理深链：该看到拒绝、登录还是引导，怎样回到可用入口？
3. 新运营员工第一次值班：谁给他账号、从哪里进入、账号过期或撤权后怎样交接未完成事项？

推荐先继承“工作人员与业务身份分离、权限由服务端判断”，优先裁定入口用途、说明、首登与恢复。是否改企业/创作者间切换是新的产品决定；明确会话独立不自动回答用户是否必须手动退出。给出实例和影响后由 owner 决定，不在本次建卡时更改旧规则。

## 输出与依赖

- 输出共享身份/登录契约草案、第一版入口图和上述代表流程画布；每项标继承/变更建议/待决及来源。
- 四端可先独立盘点；四端涉及身份边界的 Spec 定稿依赖本卡对应条款被明确接受，不要求等父任务 Done。
- 完成标准：首登、重复进入、多资格、多企业、误入口、深链、过期会话、退出/撤权和返回路径都有可复述结论；未决问题有 owner 和影响，不以一句“统一登录”替代。

## 已核验的依据与边界（2026-09-15，本地检出证据）

- Admin 文档基线：仓库 `/Users/wow/project/z-h-ai/polo-admin-dir`，分支 `POL-68/refactor/comm-defs`，HEAD `c43754bab5700f20998eef971c0ff27f36eba743`。复用 `CONTEXT.md`、`docs/adr/`、`docs/product-function-baseline.md`、`docs/user-flows-permissions-and-states.md`、`docs/product-space-contract.md` 及四端 `*-user-flows.md`。
- 第二轮支付：同仓库 `POL-94/feat/product-space-credit-recharge@9ae3e7308317fe2dce5b5fb714bd0955c7054335`，读取 `docs/payment-requirements-round2-handoff.md`、`docs/payment-round2-user-flows-and-page-states.md`、`docs/payment-round2-implementation-orchestration-plan.md` 与最新 POL-94 正文。ADR 0019 位于 POL-68 分支。第二轮是接续范围，不把两套计划机械拼成新需求。
- Admin 实现对照：`integration/pol68-g5-admin@1fbf393811bc78b02a8a2de17796b6d61d3d88ee`；`dev@04c64fd5afb14e918463c699c0994789551d6944`。集成分支 `src/app/page.tsx` 正好列出 `/login`（Platform admin login）、`/enterprise/login`、`/creator-workbench/login` 三入口，并声明独立会话、无互跳。dev 首页仍是 Platform admin login 与 Organization App management。两者不可混称当前产品。
- Client 实现对照：仓库 `/Users/wow/project/z-h-ai/polo-dir`，`integration/pol68-g5-client@3dc20ca373a9ad64c8b0701d1156a5adaf55aef8`；`dev@01f4447cf77612ca2c62d9c7155601a51bdb7b5b`。这些是本地源码基线，未验证用户正在访问的部署版本，也不是上线/验收声明。访谈开始时刷新分支、HEAD、脏改动，并记录实际体验环境（若可取得）。
- 最新 POL-68 正文保留既有模型；最新 POL-94 已收敛为 App Metering Contract 与最终跨端验收；POL-88 明确企业、创作者、staff 会话隔离及无互跳。旧卡的历史进度、Done 和文档页数不能证明当前旅程已验收。
- 已检查 Admin main/dev/POL-68/POL-94 的 `.agents/skills`：以工程执行 Skills 为主，另有 `skills/polo-bundle-compliance`；Client dev 未见 `.agents/skills`，集成分支该目录未见 SKILL.md。尚未发现适用的四端产品 policy skill；这不等于现有业务规则全部缺失，不扩张为全分支穷尽结论。
- 跨分支文档引用必须写仓库、分支/commit、路径；检查用户指出的支付文档到 `implementation-orchestration-plan.md` 的悬空相对链接。不得仅因另一分支缺文件就认定没有设计。

## 本轮协作方式与交付约定

- 用户已授权重新梳理与创建访谈任务；本卡是待访谈的 Intent 草案，不代表新 Spec/产品政策已被批准。这里不启动 Goal/Ultra、改产品代码或重置现有执行任务。
- 进入本卡后使用 `ai-native-sdlc`：先读本卡、总入口和有关的最新来源；复用仍适用的确认，只问新增或冲突的产品问题。在本卡会话访谈，一次最多 3 个问题；用户不需要先列出自己不知道的缺失功能。
- Agent 先给功能盘点和差异：每项列用户目标、来源/场景 ID、现有入口/权限/状态证据、实现与集成位置、验收证据、缺口类型、推荐下一步。缺口分为未设计、已设计未实现、已实现未集成/发布、已实现但流程不闭合、已验收、证据不足；同一项允许记录多个维度，不能用 Done 代替证据。
- 用具体人物和动作说明问题：现状 → 用户卡在哪里 → 选项 → 唯一推荐方案及影响。保留原 PC-Fxx/ENT-Fxx/CRE-Fxx/OPS-Fxx 与 S-xxx ID，新场景追加稳定 ID，不按文档自报数量宣称覆盖完成。
- 每条旅程写角色、前置状态、自然入口、页面和动作、成功结果、拒绝、空状态、失败、取消/中断、会话过期、返回与恢复、跨端交接、数据/付款责任。关键跨端场景在 Spec 草拟时用 `product-flow-canvas` 形成可点击低保真画布，逐节点讨论；源码现状与拟议行为分开标注。
- 每端输出：功能覆盖表、端内信息结构/入口图、主流程及异常恢复、跨端输入输出、policy 缺口矩阵、变更裁决清单和验收场景；至少走通首次使用、日常使用、一次失败恢复三个代表场景。来源绑定统一，画布是派生产物，产品结论在任务正文。
- 已确认规则、建议和待决问题分别标记；不把历史页面偶然行为提升成政策，不静默覆盖 POL-68/POL-94 已确认规则。发生冲突，列原依据、新例子、推荐变化、影响场景/卡片，待对应产品 owner 在本卡确认。
- 先确认怎么走，再确认长什么样。仅对仍不明确的节点做线框/关键页原型；流程确认与视觉确认分别记录。Spec 接受后才进入 Plan；本次建卡不授权开发或发布。
- 本卡完成标准是明确的产品结论与场景交付，不是已实现/已上线。产品确认人是需求提出者或其指定 owner（未指派具体访谈执行人）。需要实施的缺口在收口后关联原卡或另建增量执行卡。

<!-- POL-112:shared-identity-interview-r11:start -->

## 共享身份契约收口与四端交接 r11

本节沿用已逐项接受的共享规则，更新交接与验收映射；没有新增产品决定，整份 Spec 不因本次整理自动接受。

[打开更新后的代表流程](/__notma/open-file?path=%2FUsers%2Fwow%2Fproject%2Fz-h-ai%2Fpolo-admin-dir%2FPOL-112%2Fdocs%2Fshared-identity-entry-interview%2Fdocs%2Fshared-identity-review%2Fproduct-flow.html) · [评审材料](/__notma/open-file?path=%2FUsers%2Fwow%2Fproject%2Fz-h-ai%2Fpolo-admin-dir%2FPOL-112%2Fdocs%2Fshared-identity-entry-interview%2Fdocs%2Fshared-identity-review%2Freview.md)

# POL-112 共享身份与入口：共享契约交接版 r11

状态：本轮完成文档收口，已确认条款可供四端直接引用；整份 Spec 不因本次“继续”自动接受，未启动产品实现。本页只展示当前结论。r1—r10 历史及原文来源保存在 `history/` 和 `sources/`，历史“待决”不再充当当前待办。

## 两分钟摘要

普通业务账号可同时具有多个企业中的角色和创作者资格；平台工作人员使用独立账号。企业管理、创作者中心与平台运营为独立后台，客户端按资格提供业务快捷入口。两个业务后台支持同一 Polo 账号手机验证码登录、独立会话与过期后有权原页恢复。创作者开通、手机号不可用找回与找回交接按 MVP 线下人工流程处理。

r10 已核对 POL-77/88/90 与 POL-68 固定文档。r11 依用户“好，继续”完成交接整理：复用既有确认，补齐稳定验收场景及缺口归属，向四端、总入口和跨端收口卡同步引用。没有新增产品选择。

## 1. 哪些答案原本就有

| 可直接继承的结论 | 已核对依据 | 本次处理 |
| --- | --- | --- |
| 同一个业务账号拥有企业角色和创作者资格；staff 独立 | A-DOC CONTEXT.md:22,36—57；ADR 0006/0017；POL-77 | 不再询问是否要分成四套账号或合并 staff |
| 创作者线下审核、平台授予；授予不自动创建圈子 | A-DOC creator-workbench-user-flows.md:15—22,43—61；CONTEXT.md:47 | r3 新增确认的是 MVP 不做线上申请入口；旧线下审核原则本来就可复用 |
| 只有现有有效平台管理员可授权/撤权，最后有效管理员不可移除 | A-DOC platform-operations-user-flows.md:157—174；CONTEXT.md:57；POL-77/90 | 不重新询问授权主体或最后管理员保护 |
| 运营端过期回原页，高风险重验资料要重新填写 | A-DOC platform-operations-user-flows.md:20—21；POL-77 | 直接继承，不与业务端未提交表单的新增确认混为一谈 |
| 企业默认上次有权限企业、多企业分别计算角色、无权深链拒绝 | A-DOC enterprise-admin-user-flows.md:15—22 | 当前实现默认第一家企业是实现差异，不向产品再次提问默认选谁 |
| 已基础验证普通用户可创建企业、成为唯一 Owner；失败保留资料并幂等重试 | A-DOC enterprise-admin-user-flows.md:45—65；ADR 0009 | 沿用已确认 ENT-F01，不能因菜单只对管理员显示而阻断首次创建 |
| 退出不删除本地业务数据，资格失效保留责任只读 | A-DOC polo-client-user-flows.md:300—306；creator-workbench-user-flows.md:22,57—61 | 直接继承；具体地址/按钮/回调由工程完成 |

## 2. 这轮真正明确的新范围

| 决定 | 当前结论 | 对旧依据的影响 |
| --- | --- | --- |
| D-ID-09/10 | 有资格者右上角“创作者中心”开网页，也可收藏直达；进入另一端不用先退出 | 明确变更旧“只从客户端/先退出”规则 |
| D-ID-15 | 三个独立后台，无需统一三选一；业务快捷入口按角色/资格展示；staff 独立进入 | 收敛当前无条件三入口首页及客户端职责 |
| D-ID-11 | MVP 创作者线下联系、后台授予，不做自助申请入口/线上表单 | 在旧线下原则上明确排除已出现的线上申请页面范围 |
| D-ID-13/16 | 企业管理与创作者中心支持同一账号手机号验证码登录，首次不必先设密码 | 填补当前常规管理登录页仅密码的跨端缺口 |
| D-ID-12/16 | 两个业务后台过期重登录回仍有权原页，保留已保存内容；MVP 不承诺未提交表单恢复 | 明确业务端恢复与 MVP 保存边界 |
| D-ID-14 | 手机号不可用时线下运营核验，恢复原账号/换绑，保留关系和责任；不做自助换绑 | 明确找回范围；不解除独立治理暂停或已撤销权限 |
| D-ID-17 | 人工账号找回线下交接，各自 staff 身份操作并留审计，不新增找回交接系统 | 排除 Agent 曾泛化提出的后台待接手功能；既有治理队列不变 |
| D-ID-18（r10） | 技术初始化首个专用管理员，由指定的平台负责人持有；后续由现有管理员授权员工 | 补足首员职责，不要求访谈时指定具体姓名；没有批准部署或实际账号操作 |

D-ID-18 来源：`sources/user-decision-r10.md`。用户“同意”没有选择具体个人，不能替其指派给本人或某员工。旧确认的 r2—r9 原提问、回答与接受范围仍保留。

## 3. 当前共享契约

| 条款 | 当前规则 | 状态/来源 |
| --- | --- | --- |
| ID-C01 身份 | 一个 Polo 业务账号可以持有不同企业角色与创作者资格；工作人员账号独立 | 继承 A-DOC、POL-77 |
| ID-C02 企业 | 企业 Owner/Manager 才能管理，各企业分别鉴权；首次合法创建不要求已有企业角色 | 继承 ENT-F01 与入口定义 |
| ID-C03 入口 | 三个后台独立进入；客户端按资格提供企业/创作者快捷入口；已确认创作者右上角菜单与收藏网址 | D-ID-09/10/15；不构建普通用户必经三选一 |
| ID-C04 会话 | 各端独立维护本端会话；有效直接进、失效本端登录；不把退出另一端当进入前置 | D-ID-10；用户已委托按简单、可独立部署选择实现，不强制 SSO |
| ID-C05 认证与恢复 | 两个业务后台支持同一账号手机验证码；过期回有权原页及已保存内容，不承诺未提交表单恢复；staff 沿已有独立登录和高风险重验规则 | D-ID-12/13/16；OPS 入口定义 |
| ID-C06 创作者 | 线下联系运营、后台授予；不自动创建圈子；失效保留责任只读，无资格不生产 | D-ID-11 + CRE-F01/10 |
| ID-C07 找回与交接 | 线下运营核验恢复原账号，线下交接，各自 staff 操作留审计；不创建自助换绑/找回工单 | D-ID-14/17 |
| ID-C08 工作人员 | 首员技术初始化、指定平台负责人持有；后续已有管理员授权、撤权即时生效、最后管理员保护 | D-ID-18 + OPS-F05、POL-77/90 |
| ID-C09 数据与责任 | 退出不删业务数据；找回不变更所有权/付款责任，不恢复已撤权资格；无权目标拒绝，不泄露数据 | PC-F09、CONTEXT、D-ID-14 |
| ID-C10 付款上下文 | ProductSpace 决定数据/计量/订单目标；Manager/Member 不见企业财务详情，创作者收款另账本 | A-PAY 最新流程与 ADR 0019 |

## 4. 场景覆盖与当前缺口性质

| 场景 | 当前可复述结论 | 下一步的性质 |
| --- | --- | --- |
| 首次使用 | 无企业先进入我的空间；合法创建企业后成为唯一 Owner；创作者线下授予；管理端手机号验证码登录 | 入口接线/实现验证，不重新访谈同一规则 |
| 重复进入/多企业 | 本端有效会话直接进；有请求目标则验证目标，无目标沿用上次有权企业；逐企业检查角色 | 修正当前默认第一家企业的实现差异 |
| 多资格/独立后台 | 同账号两种业务资格独立存在，可保持两端会话；客户端快捷入口非必经门户 | 独立地址配置、会话作用域和路由迁移由工程处理 |
| 误入口/深链 | 未认证在目标端登录；认证不替代目标权限；无权拒绝；有权原目标才可恢复 | 实现安全返回与拒绝页，不把鉴权当新政策问题 |
| 会话过期 | 两业务端回有权原页及已保存内容；staff 原页恢复且高风险验证/确认/原因重新填写 | 按原/新增已确认场景验收 |
| 主动退出 | 结束本端会话，再入需认证；不删除业务数据；不承诺未提交表单自动恢复 | 不新增“退出后全端联动”或草稿系统。若未来要求该能力再提出新增范围 |
| 账号/资格被撤 | 访问权失效，不借换绑/重新登录解除治理；资格失效责任只读保留 | 按服务端现行权限验证，不静默恢复旧权限 |
| 手机号不可用/经办员工离职 | 原账号线下核验恢复；团队线下交接，接手人自己账号继续核验、变更留审计 | 运营实施说明与已有后台能力核对，不要求新增工单 |
| 返回客户端 | 后台可独立使用，不能强制先去客户端认证；提供“返回 Polo”时须与其真实目标一致，不返回无条件三选一页 | 返回按钮、应用打开及未安装说明属于实现/提示细节；不得未经要求扩大为强制安装客户端 |
| 工作人员首登 | 首员由技术初始化并交付指定平台负责人；后续现有管理员为专用 staff 授权 | 预置/交付操作与审计说明待工程落实，不在本次要求具体人员姓名 |

画布：J-ID-01 小李双资格与登录恢复；J-ID-02 小周误入口/深链；J-ID-03 工作人员首登及既有治理事件；J-ID-04 手机号不可用及线下交接。画布仅定义产品流程，不证明已实现。

## 5. 待办分流：不再都叫“产品待决”

| 原问题 | 审计后状态 | 处理 |
| --- | --- | --- |
| D-ID-01/03/04/05/06 | 对应明确确认已完成 | 分别消费 D-ID-15/10、13+14+16、11、18；不重复提问 |
| D-ID-02 合法入口/返回 | 独立入口与拒绝边界有答案；具体链接行为需实现核对 | 移出产品选择面板；按已确认规则作工程收敛，发现改变用户结果的冲突再提问 |
| D-ID-07 撤权后交接 | 找回线下交接已接受；既有治理事件已有定义 | 移出本卡新增选择；治理事件端内细节交 POL-115，不能倒推出新找回工单 |
| D-ID-08 恢复 | 两业务端过期恢复已接受，staff 规则早已存在，正常退出规则可继承 | 移出重复选择；不预先扩张跨账号或未提交草稿恢复功能 |
| 具体首员姓名、域名、Cookie/URL、初始化命令 | 执行配置/工程安排 | 保留实施待办，不阻塞产品访谈，也不冒充已完成 |
| 账号恢复核验材料、实际换绑/工作人员预置路径 | 运营/工程证据缺口 | 按已确认本人核验与审计原则补操作说明；涉及放宽验证或转移责任才请 owner 裁决 |

**本轮审计没有发现需要马上追加询问的新增产品选择。** 这不等于所有实现/验收证据齐全，也不等于整份 Spec 自动接受。后续仅把无法由已有规则推导、影响用户结果/权限/责任的冲突拿出来，按具体人物与动作说明，再提出一个推荐。

## 6. 交接范围与分工

本版直接消费 ID-C01—10、D-ID-09—18 与 §1 继承规则。没有立即需要追加产品访谈的 flagged concern。画布中的 `suggested` 表示实施提示或端内方案尚待其负责卡核对，不代表共享身份必须重新提问；已确认 decision 记录保持原 ID 与原接受版本。

| 承接卡 | 本卡交付 | 承接工作的边界 |
| --- | --- | --- |
| POO-70 客户端 | ID-C01—07/09；PC-F01/05/09、S-007；J-ID-01/02/04 | 按资格菜单、首次创建发现、浏览器与桌面返回；不把管理页保存恢复推广为第三方 App 业务结果恢复，保留 D-PC-02/03 |
| POL-113 企业 | ID-C01—05/09/10；ENT-F01/02；J-ID-01/02 | 首次创建、多企业、企业端验证码与原页恢复；本次不接受该卡其他业务建议 |
| POL-114 创作者 | ID-C01/03—07/09/10；CRE-F01/10；J-ID-01/04 | 线下授予、双入口、验证码、只读责任；不从共享规则推出 Creator Manager 或协作者 |
| POL-115 运营 | ID-C01/05—09；OPS-F05/06、S-057；J-ID-03/04 | 首员/后续授权、原账号核验与审计；账号找回线下交接不等于退款/治理事件换班已接受 |
| POL-116 跨端收口 | 本版契约、下面的 AC-ID/GAP-ID 映射 | 汇总语义冲突、可复用政策及增量实施关联；实际执行前重新绑定实现分支和环境 |

四端对应已确认条款可立即消费，不必等待 POL-112 或 POL-111 Done。各端尚未确认的业务方案仍在各端访谈，本次不替其签核；本卡整份 Spec 的接受状态也不由同步动作改变。

## 7. 共享验收场景（预期，非本轮运行结果）

沿用 PC-Fxx/ENT-Fxx/CRE-Fxx/OPS-Fxx 与 S-xxx；AC-ID 是附加验收 ID，不替换原 ID。以下共享边界为 `scenario_defined`；端内治理接手方案仅交接，不纳入本卡已确认能力。

| 验收 ID / 场景、画布 | 前置与动作 | 可判定的成功、拒绝与恢复结果 | 条款 / 承接 |
| --- | --- | --- | --- |
| AC-ID-01 双资格首登；PC-F09/CRE-F01；J-ID-01 N101—107 | 小李是 A 企业 Owner 且有有效创作者资格；从桌面先进入企业，再打开创作者中心 | 两端使用同一业务账号、本端分别认证；创作者端支持手机验证码、不先设密码；不要求退出企业；企业数据和创作者责任不混合 | ID-C01/03—05/10；POO-70、POL-113/114 |
| AC-ID-02 重复进入与多企业；ENT-F02；J-ID-01 N102—104 | 小李 A 为 Owner、B 为 Manager；分别测试有效会话、指定企业目标和无指定目标 | 有效会话可进入有权目标；无指定目标恢复上次有权限企业；各企业重验角色；不得按加入顺序替代规则或暴露无权企业 | ID-C02/04/09；POL-113 |
| AC-ID-03 误入口与深链；S-007；J-ID-02 N201—207 | 小周仅为 Member，打开 staff 登录及企业管理深链；另用有权 Owner 打开收藏的合法目标 | 未认证在目标端登录；business 不能进入 staff；Member 无权管理则拒绝且不泄露企业数据；有权目标可直达；普通用户没有必经三选一页 | ID-C01—05/09；四端 |
| AC-ID-04 业务端过期；J-ID-01 N104/110 | 已保存部分内容，编辑未提交时过期；重登录期间权限保持或失效 | 有权则回本端原页和已保存内容；不承诺未提交表单恢复，不自动发布/邀请/付款；权限失效则拒绝或转对应责任只读入口 | ID-C05/06/09；POL-113/114 |
| AC-ID-05 主动退出与取消；J-ID-01/02 | 从一个后台退出；或在登录/写入确认前取消 | 退出结束本端会话，再入需认证；另端会话按自身状态判断；业务数据保留；取消未提交动作不制造成功结果、不取消已提交服务端事实 | ID-C04/09；各端 |
| AC-ID-06 创作者无资格/零资产/失效；CRE-F01/10；J-ID-01 N108/109 | 无资格者线下申请；运营授予后首次进；再测试暂停/撤销 | 无自助申请表或在线进度承诺；授予后显示入口；零作品/圈子不自动创建圈子；失效禁止经营写入并保留责任只读；审批未通过时沿线下渠道反馈 | ID-C03/06；POO-70、POL-114/115 |
| AC-ID-07 首次创建企业；ENT-F01、S-003/029 | 无企业的已基础验证业务账号从合法创建入口创建；测试缺资料、失败、重试及取消 | 不以已有 Owner/Manager 作为创建前置；成功原子生成企业及唯一 Owner；未满足条件不创建，失败保留资料并可幂等重试；未成功不显示已建企业；返回桌面刷新不强切由 POO-70 既有边界承接 | ID-C02/09/10；POO-70、POL-113；创建页未另加画布节点 |
| AC-ID-08 staff 首登/撤权/最后管理员；OPS-F05、S-057；J-ID-03 N301—303/306/308 | 技术初始化首员交付指定负责人，已有管理员给专用 staff 授权；测试撤权和撤最后有效管理员 | 业务/staff 身份分离；仅有效授权可进入；撤权后旧会话不得治理；最后管理员操作被拒绝并保留可用管理能力；预置交付命令仍待实施核对 | ID-C01/08；POL-115 |
| AC-ID-09 staff 会话过期；J-ID-03 N304/305 | 小王处理事件时过期或提交结果未知，再认证返回 | 有权可回原事件；密码、原因、目标确认需重填；先核对结果，不自动重放高风险操作；空事件列表和加载失败不得混为一谈（端内由 POL-115 完善） | ID-C05/08/09；POL-115 |
| AC-ID-10 手机不可用与线下交接；J-ID-04 N401—407 | 小李联系运营找回；小王未完成核验即离职，小陈接手；分别测试核验通过、不通过和中断 | 团队线下交接、小陈使用自己的 staff 账号重新核对后操作；未通过不变更账号，可继续线下补材料；通过恢复原账号关系/责任；不恢复已撤权资格，不转移付款义务；实际变更留审计，不新增找回工单系统 | ID-C07—10；POL-115及两个业务后台 |

跨端返回共同断言：已有权限用户可独立使用后台，不能被强制绕回客户端认证；“返回 Polo”须符合真实目标，打不开时解释并保留可用的后台入口。具体 URL、应用打开与未安装 fallback 属实现核对，若要改为强制安装则是新的产品决定。

## 8. 实施及运营缺口移交（不在本轮开发）

Owner 以下指承接责任角色，不擅自指定个人；新产品冲突由需求提出者或其指定产品 owner 裁决。旧卡只作关联候选，不修改其锁定依据或把新范围直接塞入已执行任务。

| 缺口 ID | 类型 / 影响 | 责任归属与推荐下一步 | 原卡关联候选 |
| --- | --- | --- | --- |
| GAP-ID-01 菜单与三个后台入口 | 已实现但流程不闭合；Client 接入证据不足 | POO-70 + Admin 工程：按资格菜单、入口用途、真实返回、合法深链一起核对；AC-ID-01/03 | POL-88；由 POL-116 决定增量关联 |
| GAP-ID-02 两业务端验证码及过期恢复 | 新确认已设计；当前常规入口仅密码，完整链未验收 | Admin 认证工程 + POL-113/114：复用业务认证，补接线与恢复；AC-ID-01/04 | POL-77/88 |
| GAP-ID-03 默认企业与首次创建回程 | 已设计未实现/流程不闭合；默认第一家与原规则不符 | POL-113 + POO-70：上次有权企业、创建发现与回程；AC-ID-02/07 | POL-79/88/105 |
| GAP-ID-04 遗留线上创作者申请 | 已实现但与 MVP 确认冲突 | POL-114/115 + Admin 工程：从产品可用旅程移除在线申请依赖，保留后台授予；AC-ID-06 | POL-77/81/90 |
| GAP-ID-05 staff 预置和首员交付 | 产品职责已定；可执行操作说明/完整交付证据不足 | 平台运营负责人 + 技术负责人：补初始化、交付、授权/撤权操作说明；AC-ID-08；具体姓名和域名无需先问产品 | POL-77/90 |
| GAP-ID-06 原账号找回操作规程 | 运营/工程证据不足；核验材料和实际换绑路径未核实 | 运营负责人 + 账号服务负责人：沿本人核验、真实操作者审计与原责任不变补规程；若放宽核验/改变责任才请产品 owner 裁决；AC-ID-10 | POL-77/90；不新增找回工单 |
| GAP-ID-07 治理事件接手 | 本端机制需核对；不属于账号找回的线下交接确认 | POL-115 继续消费现有队列/领取规则，核对正常换班及撤权后的剩余动作；只对新增选择访谈 | POL-90/110；本卡不接受新增主动释放方案 |
| GAP-ID-08 当前部署与端到端验收 | 证据不足；本地分支/历史报告不代表当前用户环境 | 实施负责人 + 验收负责人在后续执行卡绑定 commit、实际环境与 AC-ID；重放跨端权限/恢复/付款责任 | POL-116 汇总，不追改历史 pass |

## 9. 本轮变更与验证边界

本轮只收口文档、同步任务正文引用与画布来源。共享产品条款仍沿 r2—r10 的逐项确认；r11 没有新增 D-ID 决定。四端正文的相关旧“待决”按接受范围纠正，其余访谈和建议保持原状态。各端离线画布由其会话消费新正文后重绑来源，本次不覆盖并行会话的本地产物。

POL-112 的当前画布保留 J-ID/N/B ID，修正旧待决提示并验证来源、模型与渲染一致。旧修订及跨卡发布前快照可追溯。未运行真实产品验收，`execution_ready` / `function_accepted` 均不能由本次文档检查推导。

## 证据附录（继承首轮源码盘点，仅更新结论状态）

## 1. 本轮证据边界

| 来源 | 本次刷新结果 | 工作树状态 |
| --- | --- | --- |
| 当前 POL-112 工作树 | `ce3bbdcecabe34f389f16ade46514b24558ee834` | 开始时干净；不是 Admin 集成基线 |
| A-DOC：Admin POL-68/refactor/comm-defs | `c43754bab5700f20998eef971c0ff27f36eba743` | 干净 |
| A-PAY：Admin POL-94/feat/product-space-credit-recharge | `9ae3e7308317fe2dce5b5fb714bd0955c7054335` | 干净 |
| A-INT：Admin integration/pol68-g5-admin | `1fbf393811bc78b02a8a2de17796b6d61d3d88ee` | 干净 |
| A-DEV：Admin dev | `04c64fd5afb14e918463c699c0994789551d6944` | 仅未跟踪 `.DS_Store`，未修改 |
| C-INT：Client integration/pol68-g5-client | `3dc20ca373a9ad64c8b0701d1156a5adaf55aef8` | 干净 |
| C-DEV：Client dev | `01f4447cf77612ca2c62d9c7155601a51bdb7b5b` | 干净 |

本轮为本地源码/文档与 Notma 最新卡片读取；没有获取用户正在体验的产品 URL/构建号，没有刷新远端 refs，没有启动服务或运行真实产品验收。Notma 的本地服务不是 Polo 产品环境。

最新读取 POL-111、112、68、77、88、90、94 及其 Activity。POL-68 历史早期评论有旧的 Creator Space/角色表述；本轮采用后续已确认四端文档与最新正文，不倒退到早期讨论。缺少产品 policy Skill 包装不等于缺少政策依据。

## 2. 身份 × 准入 × 入口 × 会话 × 落点 × 恢复 × 数据/付款

| 身份/资格 | 准入与自然入口（继承） | 实现会话与落点 | 拒绝/恢复 | 数据和付款上下文 |
| --- | --- | --- | --- | --- |
| 有效普通 business 账号，无管理资格 | Polo 桌面登录；无邀请首登进我的空间 | C-INT 支持配置开启的手机验证码与密码登录；Admin 手机注册生成 business 账号 | 会话过期需重新认证；账号暂停不可进入空间，治理轻量申诉不能恢复登录权 | 个人 ProductSpace；自己的数据/算力；加入 Circle 不新增空间 |
| 企业 Member | 桌面消费获授权企业；不能进入企业管理端 | 企业管理会话本身不足以取得任一企业管理权限，服务端再查成员关系 | 无权目标只显示拒绝，不泄露企业数据；推荐返回客户端消费入口 | 企业数据与算力归企业；第二轮不显示余额/企业财务，只能通知 Owner |
| 企业 Manager | 客户端菜单进入有权限的企业管理端 | `enterprise_session`；无 returnTo 时当前实现选最早加入的可管理企业 `/members`，未恢复上次企业 | 逐企业验证；失去角色不能沿旧深链进入；多企业切换刷新权限/数据 | 可做授权日常管理；A-PAY 已取消 Manager 企业财务详情权限 |
| 企业 Owner | 同上；首次创建企业另有合法创建入口 | 创建时业务认证，原子创建 Enterprise、ProductSpace、唯一 Owner；存在手机/密码表单 | 未基础验证不创建；失败保留资料、幂等重试；closing 保留责任入口 | Owner 管企业财务；创建确认付款责任不等于已付款，空间余额不归个人 |
| business + active 创作者资格 | r2 已确认：客户端右上角“创作者中心”或收藏网址 → 浏览器 | `creator_session` → `/creator-workbench`；同一业务账号可兼企业角色 | 没有资格当前引导申请；资格不自动创建圈子，具体 Circle Owner 单独成立 | 作品/经营上下文与企业无关；账号一套收款资料，Circle 分账，不是 ProductSpace |
| business + suspended/revoked 创作者资格 | 保留只读责任入口，直到责任交接/关闭 | 入口摘要只要有资格记录即 visible；工作台服务端检查资格状态 | 禁止创建/上传/发布等经营写入；保留历史、原因、申诉、导出，不删除责任 | 旧订单、收入及整体资产交接继续存在；不把只读入口当可消费空间 |
| staff + platform_admin | 独立平台运营登录，不从客户端进入 | 新运营页 `/operations/login` → `operations_session` → 运营页；旧 `/login` → `admin_session` → `/dashboard` 同时存在 | 普通账号被服务端拒绝；过期走本端认证，合法 returnTo；撤权不变业务账号 | 治理/健康/费用元数据；无企业成员或创作者所有权，不默认读业务内容 |
| 已预置但未授权/已撤权 staff | 现有有效管理员核验、重新认证、填原因后授予 | `changeStaffAuthorization` 只接收已是 staff 的目标；没有确认可用的完整创建/交付用户流程 | 最后有效管理员保护；已撤权人员不能靠旧会话继续治理；人工找回按 r9 线下交接；既有治理事件另沿原规则 | 审计保留真实操作者；人工找回不强制新增队列事件 |

依据：A-DOC `CONTEXT.md`、四端 `*-user-flows.md`、ADR 0006/0009/0017/0019；A-INT `auth.ts`、登录 handler、`api/me/admin-entries`、`account-qualifications.ts`、`governance.ts`；A-PAY 第二轮流程 §6。

## 3. 功能覆盖与差异盘点

E88 = 已读 POL-88 `.pipeline/acceptance-report.json`（19/19、pass）和 `result.json`，绑定最终提交 `6c258b626f9b90fa5e433205c61d0a508ced152b`，该提交是 A-INT 祖先。E90 = 已读 POL-90 报告（26/26、pass），任务 HEAD `a2f9bddfafe33a3171c4355110dfe0d5ee816062` 是 A-INT 祖先；历史报告并非当前集成重新验收。E77 只有本轮读取的历史 Activity 报告数据库/API 验收；当前任务 HEAD `9188fe75` 不是 A-INT 祖先，不能声称整个当前分支已集成；A-INT 内身份代码存在另有直接证据。

| 用户目标 / 原场景 | 文档与当前入口/权限/状态证据 | 实现/集成位置 | 验收证据与限制 | 缺口类型；推荐下一步 |
| --- | --- | --- | --- | --- |
| 找对入口 / PC-F09、S-007 | A-DOC 只从客户端；A-INT 根首页并列三登录，返回链接回 `/` | A-INT `src/app/page.tsx`、两个业务登录页；A-DEV 首页不同 | E88 包含 landing parity；不能证明首页用途被产品确认 | 已实现但流程不闭合；入口职责已由 r7 D-ID-15 确认，返回接线列为实现核对，不再列 D-ID-02 产品待决 |
| 从桌面账号菜单进管理 / PC-F09 | Admin 摘要给出企业列表和创作者资格；C-INT 搜索账号菜单、`admin-entries`、`creator-workbench` 未找到消费接入 | A-INT `api/me/admin-entries/route.ts`；C-INT HomePage/HomeSpaceContext 有企业首页外链 | E88 的 Admin/摘要验收不等于 Electron 菜单验收 | 已设计未实现（所查 Client 接入范围）+ 流程不闭合；交 POO-70 盘点，避免扩张为全分支无实现 |
| 使用有效管理深链 / ENT-F01/02、S-007 | returnTo 仅同源且本端；企业目标仍需服务端授权 | A-INT `entry-return-to.ts`、`auth.ts`、业务登录页 | E88 含跨端、过期、伪造/撤销会话；本轮未重放 | 局部历史验收；独立入口及权限规则已明确。具体安全返回参数由工程实现，无需再问是否应鉴权 |
| 重复进入正确企业 / ENT-F02 | 旧规则“上次有权限企业”；当前按 joinedAt 升序取第一家并落 members | A-INT `enterprises/manageable-entries.ts`、enterprise/login | E88 不证明 last-enterprise 规则；POL-105 概览另卡 | 已设计未实现（登录默认恢复）+ 流程不闭合；恢复规则沿用，落点按请求目标与概览职责核对 |
| 兼任 Owner 与创作者 / PC-F09、CRE-F01 | 旧规则先退出再重登录；源码独立发 cookie，登出只清本端 | A-INT 登录 handler、auth/logout | E88 证明端内隔离；未证明禁止两个会话同时存在 | 历史规则已由 r2 D-ID-10 替代：不强制先退出；采用本端有效会话复用，实施/验收仍待后续 |
| 普通成员误入口 / S-007 | staff 登录服务端拒绝 business；业务端无企业给创建/联系 Owner 引导 | A-INT login handler、enterprise/login、operations/login | E88 + E90 相关身份检查历史通过 | 局部已验收 + 返回不闭合；推荐可理解拒绝与客户端返回 |
| 新用户注册与找回 / PC-F01/09 | 手机登录可注册 business 且 passwordHash=null；桌面可在设置设密码；业务管理登录页只有密码 | C-INT AdminLoginStep、PhoneAuthStep、AccountPasswordSettingsForm；A-INT phone-auth/service、auth/password | 未核对这组跨端首登完整验收 | 已实现但流程不闭合；D-ID-13/14/16 已确定业务手机登录和线下找回，后续核对实现 |
| 首次创建企业 / ENT-F01、S-003/S-029 | 完成基础验证的普通账号可创建，不要求已有企业/创作者资格 | A-INT enterprise/create、components/enterprise-create、api/enterprises；创建页有手机/密码认证 | 本轮未核对完整创建跨桌面回程验收 | 已有设计及实现 + 客户端发现/回程证据不足；创建入口不能被“仅 Owner/Manager”挡住 |
| 申请创作者 / CRE-F01、S-040；OPS-F06、S-045/S-050 | A-DOC 线下审核、平台授予；A-INT 已有线上作品集/承诺申请表 | A-INT creator-application 页面/API；缺资格登录引导到此 | 未找到线上申请与线下审核政策衔接的明确新确认 | r3 已确认 MVP 线下联系、后台授予；已有线上申请入口需后续收敛，不启动线上收件 |
| 创作者资格失效责任处理 / CRE-F10、S-045/S-050 | 已设计保留只读；账号暂停另走轻量治理验证 | A-INT admin-entries、creator-workbench、governance/recovery | E77 历史 API、E90 治理历史；完整客户端责任入口未证 | 局部已验收 + 跨端证据不足；补资格失效、账号暂停两种分支 |
| 新员工首次值班 / OPS-F05、S-057 | bootstrap 无 staff admin 记录时读部署配置创建；普通创建用户 API 固定 business；staff 授权要求预置 staff | A-INT bootstrap、instrumentation、admin/users、changeStaffAuthorization | E90 授权历史 pass；没有员工预置/交付链证据 | 产品职责已由 D-ID-18 收口；后台员工预置/交付可执行路径仍缺证据，移交实施说明，不再问指定姓名 |
| 撤权与最后管理员 / OPS-F05、S-057 | 权限变更即生效；并发最后管理员保护；事件领取租约过期可再领 | A-INT account-qualifications、governance、operations login/session-expired | E90；本轮未验证撤权时未完成事项交接 | 局部历史验收；撤权立即生效沿用原规则，人工找回按 D-ID-17 线下交接，原治理事件由 POL-115 承接 |
| 保持付款对象 / ENT-F10、PC-CREDIT-01 | A-PAY 已限定 Owner 财务；扫码人不获产品权限；返回只主动查一次，不自动执行 | A-PAY 交接、流程、编排计划；POL-94 当前收敛 App Metering Contract/D-1 | 第二轮最终跨端验收未由本轮验证 | 已设计 + 集成/发布证据不足；继承最新规则，按 POL-94 下游追溯，禁止入口切换改变旧订单目标 |

注意：C-INT `HomePage.tsx:createEnterpriseWorkflowUrl` 的作品链接生成 `/organization-apps?organizationId=...`；这是旧入口依赖的源码证据。不能据此断言最终一定 404，需运行重放其退役/跳转响应。Member 首页也显示相关外链，并非旧规则要求的仅 Owner/Manager 账号菜单入口。


## 8. 来源索引与跨分支链接核查

Admin 仓库根：`/Users/wow/project/z-h-ai/polo-admin-dir`。Client 仓库根：`/Users/wow/project/z-h-ai/polo-dir`。以上 A/C 代号的 branch/完整 commit 见 §1，路径均相对各 Git 工作树根。

- A-DOC：`CONTEXT.md`；`docs/product-function-baseline.md`；`docs/user-flows-permissions-and-states.md`；`docs/product-space-contract.md`；`docs/polo-client-user-flows.md`；`docs/enterprise-admin-user-flows.md`；`docs/creator-workbench-user-flows.md`；`docs/platform-operations-user-flows.md`；`docs/adr/0006-creator-is-a-platform-approved-account-qualification.md`、`0009-enterprise-has-one-transferable-owner-and-simple-groups.md`、`0017-platform-admins-use-dedicated-staff-accounts.md`、`0019-runtime-metering-and-prepaid-recharge-are-separate.md`。
- A-PAY：`docs/payment-requirements-round2-handoff.md`、`docs/payment-round2-user-flows-and-page-states.md`、`docs/payment-round2-implementation-orchestration-plan.md`。前两份指向 `./implementation-orchestration-plan.md` 的链接在该提交悬空；对应第一轮文件存在于 **Admin POL-68/refactor/comm-defs@c43754bab5700f20998eef971c0ff27f36eba743:docs/implementation-orchestration-plan.md**。本轮在来源记录纠正引用，不修改另一工作树或拼接两套计划。
- A-INT 登录/入口：`src/app/page.tsx`、`src/app/login/page.tsx`、`src/app/operations/login/page.tsx`、`src/app/enterprise/login/page.tsx`、`src/app/creator-workbench/login/page.tsx`、`src/app/api/auth/login/handler.ts`、`src/app/api/auth/logout/route.ts`、`src/lib/auth.ts`、`src/lib/entry-return-to.ts`。
- A-INT 身份/开通：`src/lib/bootstrap.ts`、`src/instrumentation.ts`、`src/lib/account-qualifications.ts`、`src/lib/governance.ts`、`src/lib/phone-auth/service.ts`、`src/app/api/auth/password/route.ts`、`src/app/api/admin/users/route.ts`、`src/app/api/me/admin-entries/route.ts`、`src/lib/enterprises/manageable-entries.ts`、`src/components/enterprise-create.tsx`、`src/app/creator-application/page.tsx`、`src/app/api/creator-application/route.ts`。
- C-INT：`apps/electron/src/renderer/components/onboarding/AdminLoginStep.tsx`、`PhoneAuthStep.tsx`；`apps/electron/src/renderer/pages/settings/AccountPasswordSettingsForm.tsx`；`apps/electron/src/renderer/components/tab-browser/HomePage.tsx`；`apps/electron/src/renderer/components/product-space/HomeSpaceContext.tsx`。早期 `docs/usecase-spec-electron-login.md` 的“管理员手工建号/找回、暂停延迟生效”不作为当前四端规则；源码已增手机注册，暂停即时撤权以 A-DOC 后续确认和 POL-90 为准。

本轮不做实现、提交、推送或上线，不变更其他执行任务。待本卡条款逐项接受后，相应端才能定稿涉及该条款的 Spec；不要求等待 POL-111 Done。先继续访谈，不进入 Plan。

<!-- POL-112:shared-identity-interview-r11:end -->

